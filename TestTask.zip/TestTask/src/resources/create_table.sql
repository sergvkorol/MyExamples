CREATE DEFINER=`skorol`@`localhost` PROCEDURE `create_table`()
BEGIN
CREATE TABLE PhoneBook
(
  id      		int AUTO_INCREMENT NOT NULL,
  first_name    char(50)  NOT NULL,
  last_name 	char(50)  NOT NULL,
  date_birth 	date null,
  city    		char(25)  NULL,
  country 		char(20)  NULL,
  phone_number 	varchar(15)  NOT NULL,
  email   		varchar(50) NULL,
  PRIMARY KEY (id) 
);

END