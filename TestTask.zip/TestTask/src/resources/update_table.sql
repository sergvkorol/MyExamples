INSERT INTO phonebook (id, first_name, last_name, date_birth, city, country, phone_number, email) 
VALUES(1, 'Sergey', 'Korol', '1972-08-30', 'Kharkiv', 'Ukraine', '380966015980', 'karych@ukr.net');
INSERT INTO phonebook (id, first_name, last_name, date_birth, city, country, phone_number, email) 
VALUES(2, 'Ivan', 'Ivanov', '1992-01-01', 'Kyiv', 'Ukraine', '380501234567', 'ivanov@mail.ru');
INSERT INTO phonebook (id, first_name, last_name, date_birth, city, country, phone_number, email) 
VALUES(3, 'Sydor', 'Sydorov', '1981-10-07', 'Paris', 'France', '380637654321', 'sydorov@yandex.ru');
INSERT INTO phonebook (id, first_name, last_name, date_birth, city, country, phone_number, email) 
VALUES(4, 'Petr', 'Petrov', '1901-01-01', 'Lviv', 'Ukraine', '380502222222', 'petrov@mail.ru');

