package com.company.config;

import java.sql.*;
import java.util.ArrayList;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import java.io.*;

public class DataBaseAction {	
//	private String url = "jdbc:mysql://localhost:3306/testtask";
//	private String login = "skorol";
//	private String password = "pass";
	private String action;
	private int index = 9999;
	private String[] data;
	private int result;
	
	public int getResult() {
		return result;
	}

	public DataBaseAction (String action) {		
		this.action = action;		
	}
	
	public DataBaseAction (String action, int index) {		
		this.action = action;
		this.index = index;		    
	}
	
	public DataBaseAction (String action, String[] data) {		
		this.action = action;
		this.data = data;		    
	}	
	
	
	public ArrayList<String> doAction() throws IOException, NamingException {
		ArrayList<String> array = new ArrayList<>();
		
			try {
				  Class.forName("com.mysql.jdbc.Driver");
			} 
			catch (ClassNotFoundException e) {
				    System.out.println("Can't find MySQL JDBC Driver?");
				    e.printStackTrace();
				    return null;
			}
			
			try {
				
				InitialContext initContext= new InitialContext();
				DataSource ds = (DataSource) initContext.lookup("java:comp/env/jdbc/appname");
				Connection conn = ds.getConnection();
				
				//Connection conn = DriverManager.getConnection(url, login, password);
				Statement stat = conn.createStatement();
				String doAction = "";
				
				
				if (action.equals("delete") && index!= 9999) {
					doAction="delete from phonebook where id =" + index;					
					stat.execute(doAction);
					//System.out.println("Action " + action + " was completed successfully");
				}
				else if (action.equals("update")) {
					int id = Integer.parseInt(data[0]);					
					doAction="update phonebook set " +
						" id = " + id + "," +
						" first_name = '" + data[1] + "'," +
						" last_name = '" + data[2] + "'," +
						" date_birth = '" + data[3] + "'," +
						" phone_number = '" + data[4] + "'" +
						" where id = " + id;					
					stat.execute(doAction);	
					//System.out.println("Action " + action + " was completed successfully");
				}
				else if(action.equals("insert")) {										
					doAction = "INSERT INTO phonebook (first_name, last_name, date_birth, phone_number) VALUES(" +
							"'" + data[0] + "', " +
							"'" + data[1] + "', " +
							"'" + data[2] + "', " +
							"'" + data[3] + "')";
					stat.execute(doAction);	
					//System.out.println("Action " + action + " was completed successfully");
				}
				//This case of select is for single row selection. That's why index != 9999
				else if (action.equals("select") && index!= 9999) {					
					doAction="select * from phonebook where id = " + index;
					ResultSet rs = stat.executeQuery(doAction);
					while (rs.next()) {
						String temp = rs.getString("id") + " " +
								rs.getString("first_name") + " " +
								rs.getString("last_name") + " " +
								rs.getString("date_birth") + " " +
								rs.getString("phone_number");						
						array.add(temp);
					}					
					System.out.println("Action simple " + action + " was completed successfully");
					rs.close();
					conn.close();
					return array;
				}
				
				doAction="select * from phonebook";				
				ResultSet rs = stat.executeQuery(doAction);
								
				while (rs.next()) {
					String temp = rs.getString("id") + " " +
							rs.getString("first_name") + " " +
							rs.getString("last_name") + " " +
							rs.getString("date_birth") + " " +
							rs.getString("phone_number");
					array.add(temp);					
				}
				rs.close();			
				conn.close();
			}
			catch(SQLException e) {
				System.out.println("Action " + action + " wasn't completed");	
				e.printStackTrace();
			}
			return array;
	}
}
