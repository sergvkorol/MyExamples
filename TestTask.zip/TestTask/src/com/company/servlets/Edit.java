package com.company.servlets;

import java.io.IOException;
import java.util.ArrayList;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.company.config.DataBaseAction;

@WebServlet("/Edit")
public class Edit extends HttpServlet {
	private static final long serialVersionUID = 1L;
	DataBaseAction db;
	ArrayList<String> arr;
       
        public Edit() {
        	super();        
        }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
		
		String action = request.getParameter("action");
		try {
		if ("Cancel".equals(action)) {
			db = new DataBaseAction("select");			
			arr = db.doAction();			
		    request.setAttribute("phonebook", arr);
			request.getRequestDispatcher("main.jsp").forward(request, response);			
		}
		else if ("Save".equals(action)) {
			String[] temp = request.getParameterValues("data");						
			db = new DataBaseAction("update", temp);			
			arr = db.doAction();
		    request.setAttribute("phonebook", arr);
			request.getRequestDispatcher("main.jsp").forward(request, response);
		}
		else if ("Add".equals(action)) {
			String[] temp = request.getParameterValues("data");
			db = new DataBaseAction("insert", temp);
			arr = db.doAction();
		    request.setAttribute("phonebook", arr);
			request.getRequestDispatcher("main.jsp").forward(request, response);
		}
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}

}
