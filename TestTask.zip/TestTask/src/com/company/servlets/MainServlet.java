package com.company.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.company.config.DataBaseAction;


@WebServlet("/MainServlet")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private DataBaseAction db;
    private ArrayList<String> arr;   
    
    public MainServlet() {
        super();        
    }
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String action = request.getParameter("action");
		String[] index = request.getParameterValues("edit");
		int[] idx = {};	
		
		try {
			if (index != null && index.length != 0) {
				idx = new int[index.length];
				for (int i=0; i<index.length; i++) {
					idx[i]=Integer.parseInt(index[i]);
				}			
			}
					
			if ("Edit".equals(action)) {			
				if (idx.length == 1) {
					db = new DataBaseAction("select");
					arr = db.doAction();
					int[] indexArr = new int[arr.size()];	    
				    for (int i=0; i<arr.size(); i++) {
				    	String temp = arr.get(i);
				    	int ind = temp.indexOf(" ");
				    	ind = Integer.parseInt(temp.substring(0, ind));
				    	indexArr[i]=ind;
				    }
				    for (int i=0; i<arr.size(); i++) {
					    if (idx[0] == i) {
				    		db = new DataBaseAction("select", indexArr[i]);			    		
				    		break;
				    	}
				    }
									
					arr = db.doAction();
					String temp = arr.get(0);
				    request.setAttribute("phonebook", temp);
				    request.setAttribute("flagAdd", "false");
				    request.setAttribute("flagSave", "true");
				    request.getRequestDispatcher("edit.jsp").forward(request, response);
				}
				else if (idx.length == 0){
					String temp = "first_name last_name 1900-01-01 phone_number";
					request.setAttribute("phonebook", temp);
					request.setAttribute("flagAdd", "true");
				    request.setAttribute("flagSave", "false");
				    request.getRequestDispatcher("edit.jsp").forward(request, response);
				}
				else {				
					PrintWriter out = response.getWriter();
					out.println("<script type=\"text/javascript\">");				
					out.println("alert('Please select just ONE row to be edited');");
					out.println("</script>");
					out.close();								
				}
			} 
			else if ("Delete".equals(action)) {
				if (idx.length == 1) {
					db = new DataBaseAction("select");
					arr = db.doAction();
					int[] indexArr = new int[arr.size()];	    
				    for (int i=0; i<arr.size(); i++) {
				    	String temp = arr.get(i);
				    	int ind = temp.indexOf(" ");
				    	ind = Integer.parseInt(temp.substring(0, ind));
				    	indexArr[i]=ind;
				    }
				    
				    for (int i=0; i<arr.size(); i++) {
					    if (idx[0] == i) {
				    		db = new DataBaseAction("delete", indexArr[i]);
				    		//arr = db.doAction();
				    		break;
				    	}
				    }
				}
				else {				
					for (int j=0; j<idx.length; j++) {					
						db = new DataBaseAction("select");
						arr = db.doAction();
						int[] indexArr = new int[arr.size()];	    
					    for (int i=0; i<arr.size(); i++) {
					    	String temp = arr.get(i);
					    	int ind = temp.indexOf(" ");
					    	ind = Integer.parseInt(temp.substring(0, ind));
					    	indexArr[i]=ind;
					    }
					    
					    for (int i=0; i<arr.size(); i++) {
						    if (idx[j] == i) {					    	
					    		db = new DataBaseAction("delete", indexArr[i]);				    		
					    		continue;
					    	}
					    }
					}
				}
				arr = db.doAction();
			    request.setAttribute("phonebook", arr);
			    request.getRequestDispatcher("main.jsp").forward(request, response);			
			}
			else if ("Refresh".equals(action)){
				db = new DataBaseAction("select");
				arr = db.doAction();			
				
				String[] indexArr = new String[arr.size()];	    
			    for (int i=0; i<arr.size(); i++) {
			    	String temp = arr.get(i);
			    	int ind = temp.indexOf(" ");
			    	temp = temp.substring(0, ind);
			    	indexArr[i]=temp;
			    }
			    request.setAttribute("phonebook", arr);
			    request.getRequestDispatcher("main.jsp").forward(request, response);
			}
		} catch (NamingException e) {			
			e.printStackTrace();
		}
	}
}
