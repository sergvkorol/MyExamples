package com.company.servlets;

import java.io.IOException;
import java.util.ArrayList;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.company.config.DataBaseAction;

@WebServlet("/Buttons")
public class Buttons extends HttpServlet {
	private static final long serialVersionUID = 1L;	
    
    public Buttons() {
        super();        
    }
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		DataBaseAction db = new DataBaseAction("select");
		ArrayList<String> arr;
		try {
			arr = db.doAction();
		    request.setAttribute("phonebook", arr);
		    request.getRequestDispatcher("main.jsp").forward(request, response);
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		doGet(request, response);
	}

}
