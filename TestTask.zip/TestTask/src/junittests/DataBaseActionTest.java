package junittests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.company.config.DataBaseAction;

import java.io.IOException;
import java.util.ArrayList;

import javax.naming.NamingException;

public class DataBaseActionTest {
	DataBaseAction db;
	ArrayList<String> arr;
	@Before
	public void testConnect() {
		
	}	
	
	@Test
	public void testSelect() throws IOException {
		try {
			db= new DataBaseAction("select");
			arr = db.doAction();	    
		    assertNotNull("Recieved array is not empty",arr);
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}
	/*
	@Test
	public void testDelete() throws IOException {		
		db= new DataBaseAction("delete", 1);
		arr = db.doAction();
		db= new DataBaseAction("select", 1);
		arr = db.doAction();
		assertEquals("Record was deleted", 0, arr.size());
	    
	}
	@Test
	public void testDeleteFail() throws IOException {
		db= new DataBaseAction("delete", 200);
		arr = db.doAction();
		int length = arr.size();
		db= new DataBaseAction("select");
		arr = db.doAction();
		assertEquals("Record wasn't deleted", length, arr.size());
	}
	@Test
	public void testInsert() throws IOException {
		db= new DataBaseAction("select");
		arr = db.doAction();
		int length = arr.size();
		String[] temp = {"first_name", "last_name", "1900-01-01", "phone_number"};
		db= new DataBaseAction("insert", temp);
		arr = db.doAction();
		assertEquals("Record was updated", length+1, arr.size());
	}
	@Test
	public void testUpdate() throws IOException {		
		//TODO finish later
	}	*/
}
